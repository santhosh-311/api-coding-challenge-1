package com.hexaware.webtoken;

public record LoginForm (String username,String password){
	
}
