package com.hexaware.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class UsersDTO {
	
	private int userId;
	
	@NotBlank(message="UserName cannot be empty")
    @Pattern(regexp = "^[A-Za-z ]{5,30}$", message = "Can contain alphabets,spaces, length should be between 5 and 30")
	private String userName;
	
	@NotNull(message = "Password should not be null")
    @Size(min = 8, message = "Password should have at least 8 characters")
    @Pattern(regexp = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$", message = "Password must contain at least one uppercase letter, one number, and one special character")
	private String password;
	
	private String number;
	private LocalDate dob;
	private String gender;
	private String city;
	private String state;
	private String country;
	private String role;
	
	public UsersDTO() {
		super();
	}

	public UsersDTO(int userId,
			@NotBlank(message = "UserName cannot be empty") @Pattern(regexp = "^[A-Za-z ]{5,30}$", message = "Can contain alphabets,spaces, length should be between 5 and 30") String userName,
			@NotNull(message = "Password should not be null") @Size(min = 8, message = "Password should have at least 8 characters") @Pattern(regexp = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$", message = "Password must contain at least one uppercase letter, one number, and one special character") String password,
			String number, LocalDate dob, String gender, String city, String state, String country, String role) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.number = number;
		this.dob = dob;
		this.gender = gender;
		this.city = city;
		this.state = state;
		this.country = country;
		this.role = role;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return String.format(
				"UsersDTO [userId=%s, userName=%s, password=%s, number=%s, dob=%s, gender=%s, city=%s, state=%s, country=%s, role=%s]",
				userId, userName, password, number, dob, gender, city, state, country, role);
	}
	
	
}
