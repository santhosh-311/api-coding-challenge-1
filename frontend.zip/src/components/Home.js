import { useContext } from "react";
import Header from "./Header";
import DataContext from "./DataContext";
import Books from "./Books";

const Home=()=>{

    const {userDetails} = useContext(DataContext)
    return(
        <>
        <Header/>
        {
            userDetails!==""?<Books/>:<h2>Please Login</h2>
        }
        </>
    )
}
export default Home;