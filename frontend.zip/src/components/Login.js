import React, { useContext, useEffect, useState } from "react";
import { Modal, Button, Input,  Typography } from "antd";
import { EyeInvisibleOutlined, EyeTwoTone } from "@ant-design/icons";
import DataContext from "./DataContext";

const { Text } = Typography;

const Login = ({login}) => {
  const{loginFlag,setSignupFlag }=useContext(DataContext)
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const showModal = () => {
    setIsModalOpen(true);
  };

  useEffect(()=>{
    if(loginFlag===false){
      setIsModalOpen(true);
    }
  },[loginFlag])


  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  return (
    <div>
      <Button type="primary" onClick={showModal}>
        Login
      </Button>
      <Modal
        title={<h2>Sign In</h2>}
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        footer={null}
        width={400}
      >
        <Input
          placeholder="Enter email address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          style={{ marginTop: 20 }}
        />
        <Input.Password
          placeholder="Enter password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          iconRender={(visible) =>
            visible ? <EyeTwoTone /> : <EyeInvisibleOutlined />
          }
          style={{ marginTop: 15 }}
        />
        <div style={{ textAlign: "right", marginTop: 10 }}>
          <a href="/forgot-password">Forgot password?</a>
        </div>
        <Button
          type="primary"
          block
          onClick={()=>{
            login(email,password);
            handleOk();
          }}
          style={{ marginTop: 20 }}
        >
          Sign In
        </Button>
        <div style={{ textAlign: "center" }}>
          <Text>Don't have an account yet? </Text>
          <button className="signup-link-btn" onClick={()=>{
            setSignupFlag(false);
            handleCancel();
          }}>Sign up here</button>
        </div>
      </Modal>
    </div>
  );
};

export default Login;