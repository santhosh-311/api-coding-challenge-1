import React, { useContext } from "react";
import { Form, Input, Button, message } from "antd";
import axios from "axios";
import Header from "./Header";
import DataContext from "./DataContext";
import '../styles/Profile.css'

const BASE_URL = "http://localhost:8084/";

const Profile = () => {
  const { userDetails} = useContext(DataContext);

  const handleChangePassword = async (values) => {
    console.log(values)
    try {
      await axios.put(
        `${BASE_URL}user/update/${userDetails.userName}/${values.password}`,
        {},
        {
          headers: { Authorization: `Bearer ${userDetails.jwt} `},
        }
      );
      message.success("Password updated successfully!");
    } catch (error) {
      message.error("Failed to update password.");
    }
  };

  return (
    <>
      <Header />
      <div style={{ padding: "20px", maxWidth: "900px", margin: "10px 60px 20px" }}>
        <button className={"top-btn"}>
            Change Password
        </button>
        <Form layout="vertical" 
            onFinish={handleChangePassword}
            style={{ margin: "20px" }}
        >
          <Form.Item
            label="New Password"
            name="password"
            rules={[
                { 
                  required: true, 
                  message: "Password is required." 
                },
                {
                  pattern: /^(?=.*[A-Z])(?=.*[0-9])(?=.*[@$!%*?&])[A-Za-z0-9@$!%*?&]{8,}$/,
                  message: "At least 1 uppercase letter, 1 digit, 1 special character, and a minimum length of 8 characters."
                }
              ]}
              
          >
            <Input.Password placeholder="Enter new password" />
          </Form.Item>
          <Button type="primary" htmlType="submit">
            Change Password
          </Button>
        </Form>
      </div>
    </>
  );
};

export default Profile;