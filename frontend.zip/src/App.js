import './App.css';
import Routing from './components/Routing';
import { DataProvider } from './components/DataContext';

function App() {
  return (
    <div className="min-h-screen bg-gray-100 app">
      <DataProvider>
        <Routing/>
      </DataProvider>
    </div>
  );
}

export default App;
